J2534Diag R30 - focused Mode06 correctness preview
Keep R29 and R28 unchanged in separate folders.
GM reference labels do not establish SRX monitor support.
No physical R30 acceptance; no owner vehicle test requested.
SourceCommit=bb602372a5a1e9832b892fadf2cf45279d7f145a
