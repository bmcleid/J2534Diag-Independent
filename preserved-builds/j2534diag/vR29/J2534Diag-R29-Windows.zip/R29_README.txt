J2534Diag R29 - Saved session review
Extract in a separate folder and keep R28 as fallback.
Run J2534Diag.exe; choose Saved session; choose Open saved session.
Example-Synthetic-Session.csv is synthetic test data, not a vehicle recording.
Review is offline and makes no ECU requests. No adapter connection is needed.
Only this app scalar Schema=2 report CSVs are supported; see owner R29 record.
Physical R29 adapter/vehicle acceptance remains unverified.
SourceCommit=2aa3d43a0c5e3fe2c913e2a8b96d90f91157c249
