J2534Diag R31 - bounded Mode06 advertised-support discovery
One discovery and result snapshot per Misfire tab start; restart by changing tabs.
Advertised MID support does not prove TID/scaling or SRX calibration interpretation.
The generic eight-cylinder reference list does not identify this vehicle as eight-cylinder.
Keep accepted R30 in a separate folder. No vehicle test requested.
Discovery: one 06 00 functional request; advertised continuation/results directed per source.
App policy: 300 ms response window; 50 ms gap; 128 requests / 30 seconds scheduling cap.
Driver calls themselves cannot be preempted by the scheduling cap.
SourceCommit=251ea31474de339e754f9057c070e8fe375e365e
